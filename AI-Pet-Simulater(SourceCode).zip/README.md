# ChatWithCat
An interactive pet game where you can chat with a virtual pet that understands your commands using basic AI. The pet can play, eat, and sleep based on your interactions. Built with C++ and SFML, this game offers a fun, cute, and engaging experience with AI-powered conversations and actions.
